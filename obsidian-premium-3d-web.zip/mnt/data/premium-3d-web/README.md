# OBSIDIAN — Premium 3D Commerce Demo

A responsive Vite + React frontend combining an interactive 3D hero, swipe scene transitions, portfolio, storefront, persistent cart, checkout, payment simulation, sales analytics, admin shell and contact flow.

## Run

```bash
npm install
npm run dev
```

## Stack

- React + Vite
- Three.js + React Three Fiber + Drei
- Framer Motion
- Recharts
- Lucide React
- localStorage for cart persistence

## Notes

- Product and analytics data are demo data.
- Payment is simulation-only. No real transaction API is called.
- Images use remote Unsplash sources and lazy loading.
- The app is a single Vite SPA for easy deployment. Components are kept logically separated enough to extract into `components/`, `sections/`, and `pages/` later without rewriting the UI model.
